// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2017-2020 Egor Pugin <egor.pugin@gmail.com>

// C public routines

#ifndef _SWC_H_
#define _SWC_H_

/// everything for building
SW_PACKAGE_API
void build(sw_build_t *);

#endif
